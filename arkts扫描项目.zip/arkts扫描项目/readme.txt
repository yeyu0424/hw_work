camera组件：https://gitcode.com/openharmony/applications_camera
扫描结果：camera_report.json

photos组件：https://gitcode.com/openharmony/applications_photos
扫描结果：photos_report.json